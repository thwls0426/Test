package com.example.jebal.demo.kakao;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequiredArgsConstructor
@Controller
public class KakaoController {

    @RequestMapping(value="/katalk/callback")
    public String login(@RequestParam("code") String code) {
        System.out.println("code : " + code);
        return "index";
    }

}
