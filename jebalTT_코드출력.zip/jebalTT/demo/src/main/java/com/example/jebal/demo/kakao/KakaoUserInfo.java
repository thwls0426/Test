package com.example.jebal.demo.kakao;

public class KakaoUserInfo {
}
