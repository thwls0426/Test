package com.example.login_test.user;

import com.example.login_test.core.error.exception.Exception400;
import com.example.login_test.core.error.exception.Exception401;
import com.example.login_test.core.error.exception.Exception500;
import com.example.login_test.core.security.CustomUserDetails;
import com.example.login_test.core.security.JwtTokenProvider;
import com.example.login_test.core.utils.SignUpMessageSender;
import com.google.gson.JsonParser;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.bcel.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpSession;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;


/* 메서드나 클래스에 적용가능.
 * Transactional
 * 어노테이션이 적용된 메서드가 호출되면, 새로운 트랜잭션이 시작됨.
 * 메서드 실행이 성공적으로 완료되면, 트랜잭션은 자동으로 커밋.
 * 메서드 실행 중에 예외가 발생하면, 트랜잭션은 자동으로 롤백.
 *
 ** readOnly = true : 이 설정은 해당 트랜잭션이 데이터를 변경하지 않고 읽기전용으로만 사용이 가능하다는것을 명시적으로 나타냄.
 * */
@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class UserService {
    public static OAuth2UserService<OAuth2UserRequest, OAuth2User> KakaoOAuth2UserService;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final HttpSession httpSession;

    @Transactional
    public void join(UserRequest.JoinDTO requestDTO) {
        checkEmail(requestDTO.getEmail());

        String encodedPassword = passwordEncoder.encode( requestDTO.getPassword());

        requestDTO.setPassword(encodedPassword);

        try {
            userRepository.save(requestDTO.toEntity());

            SignUpMessageSender.sendMessage("01088224115", requestDTO.getPhoneNumber()
                ,"환영합니다. 회원가입이 완료되었습니다.");

        }catch (Exception e){
            throw new Exception500(e.getMessage());
        }
    }

    public String login(UserRequest.JoinDTO requestDTO) {
        // ** 인증 작업.
        try{
            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken
                    = new UsernamePasswordAuthenticationToken(requestDTO.getEmail(), requestDTO.getPassword());

            Authentication authentication =  authenticationManager.authenticate(
                    usernamePasswordAuthenticationToken
            );

            // ** 인증 완료 값을 받아온다.
            CustomUserDetails customUserDetails = (CustomUserDetails)authentication.getPrincipal();

            // ** 토큰 발급.
            return JwtTokenProvider.create(customUserDetails.getUser());

        }catch (Exception e){
            // 401 반환.
            throw new Exception401("인증되지 않음.");
        }


    }

    public void findAll() {
        List<User> all = userRepository.findAll();
        for(User user : all){
            user.output();
        }
    }

    public void checkEmail(String email){
        // 동일한 이메일이 있는지 확인.
        Optional<User> users = userRepository.findByEmail(email);
        if(users.isPresent()) {
            throw new Exception400("이미 존재하는 이메일 입니다. : " + email);
        }
    }



//    @RequiredArgsConstructor
//    public class KakaoOAuth2UserService extends DefaultOAuth2UserService {
//
//        private final HttpSession httpSession;
//
//        @Override
//        public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
//            OAuth2User oAuth2User = super.loadUser(userRequest);
//            Map<String, Object> attributes = oAuth2User.getAttributes();
//
//            log.info("attributes :: " + attributes);
//
//            httpSession.setAttribute("login_info", attributes);
//
//            return new DefaultOAuth2User(Collections.singleton(new SimpleGrantedAuthority("ROLE_USER")),
//                    oAuth2User.getAttributes(), "id");
//        }
//    }


//        @Autowired
//        public HttpCallService httpCallService;
//
//
//        @Value("${f12393a3d014f5b41c1891bca7f2c800}")
//        private String REST_API_KEY;
//
//        @Value("${redirect-uri}")
//        private String REDIRECT_URI;
//
//        @Value("${authorize-uri}")
//        private String AUTHORIZE_URI;
//
//        @Value("${token-uri}")
//        public String TOKEN_URI;
//
//        @Value("${client-secret}")
//        private String CLIENT_SECRET;
//
//        @Value("${kakao-api-host}")
//        private String KAKAO_API_HOST;
//
//
//        public RedirectView goKakaoOAuth() {
//            return goKakaoOAuth("");
//        }
//
//        public RedirectView goKakaoOAuth(String scope) {
//
//            String uri = AUTHORIZE_URI+"?redirect_uri="+REDIRECT_URI+"&response_type=code&client_id="+REST_API_KEY;
//            if(!scope.isEmpty()) uri += "&scope="+scope;
//
//            return new RedirectView(uri);
//        }
//
//        public RedirectView loginCallback(String code) {
//            String param = "grant_type=authorization_code&client_id="+REST_API_KEY+"&redirect_uri="+REDIRECT_URI+"&client_secret="+CLIENT_SECRET+"&code="+code;
//            String rtn = httpCallService.Call(Const.POST, TOKEN_URI, Const.EMPTY, param);
//            httpSession.setAttribute("token", Trans.token(rtn, new JsonParser()));
//            return new RedirectView("/index.html");
//        }
//
//        public String getProfile() {
//            String uri = KAKAO_API_HOST + "/v2/user/me";
//            return httpCallService.CallwithToken(Const.GET, uri, httpSession.getAttribute("token").toString());
//        }
//
//        public String getFriends() {
//            String uri = KAKAO_API_HOST + "/v1/api/talk/friends";
//            return httpCallService.CallwithToken(Const.GET, uri, httpSession.getAttribute("token").toString());
//        }
//
//        public String message() {
//            String uri = KAKAO_API_HOST + "/v2/api/talk/memo/default/send";
//            return httpCallService.CallwithToken(Const.POST, uri, httpSession.getAttribute("token").toString(), Trans.default_msg_param);
//        }
//    }
}






