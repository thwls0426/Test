package com.example.login_test.kakao;


import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
@RequestMapping
public class KakaoController {
    private KakaoService kakao_service = new KakaoService();

    @GetMapping(value = "/kakao/oauth")// method = RequestMethod.GET)
    public String kakaoConnect(){
        StringBuffer url = new StringBuffer();
        url.append("http://kauth.kakao.com/oauth/authorize?");
        url.append("client_id="+"f12393a3d014f5b41c1891bca7f2c800");
        url.append("&redirect_uri=http://localhost:8080/kakao/callback");
        url.append("&response_type=" + "code");
        return "redirect:" + url.toString();

    }

    @GetMapping(value = "/kakao/callback", produces = "applicaiton/json")// method = {RequestMethod.GET,RequestMethod.POST})
    public String kakaoLogin(String code) {
        System.out.println("kakao code : " + code);
        JsonNode access_token= kakao_service.getKakaoAccessToken("code");
        // access_token.get("access_token");
        //   System.out.println("access_token:" + access_token.get("access_token"));

        JsonNode userInfo = KakaoUserInfo.getKakaoUserInfo(access_token.get("access_token"));

        // Get id
        String member_id = userInfo.get("id").asText();

        String member_name = null;

        // 유저정보 카카오에서 가져오기 Get properties
        JsonNode properties = userInfo.path("properties");
        JsonNode kakao_account = userInfo.path("kakao_account");
        member_name = properties.path("nickname").asText(); //이름 정보 가져오는 것
        // email = kakao_account.path("email").asText();

        System.out.println("id : " + member_id);    //여기에서 값이 잘 나오는 것 확인 가능함.
        System.out.println("name : " + member_name);

        return "redirect:/index.do";
    }


    }



//    @Value("${cos.key")
//    private String cosKey;

//    @GetMapping("/auth/kakao/callback")
//    public String kakaoCallback(String code) {
//
//        RestTemplate rt = new RestTemplate();
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
//
//        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
//        params.add("grant_type", "authorization_code");
//        params.add("client_id", "f12393a3d014f5b41c1891bca7f2c800");
//        params.add("redirect_uri", "http://localhost:8080/kakao/callback");
//        params.add("response_type", code);
//
//        HttpEntity<MultiValueMap<String, String>> kakaoRequest = new HttpEntity<>(params, headers);
//
//        ResponseEntity<String> response = rt.exchange("https://kauth.kakao.com/oauth/token",
//                HttpMethod.POST,
//                kakaoRequest,
//                String.class
//        );
//
//        ObjectMapper objectMapper = new ObjectMapper();
//        OAuth2Token oAuth2Token = null;
//
//        try {
//            oAuth2Token = objectMapper.readValue(response.getBody(), OAuth2Token.class);
//        } catch (JsonMappingException e) {
//            e.printStackTrace();
//        } catch (JsonProcessingException e) {
//            e.printStackTrace();
//        }
//
//
//    return "redirect" + "http://localhost:8080/kakao/callback";}



