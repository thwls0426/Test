package com.example.login_test.kakao;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class KakaoUserInfo  {

    public static JsonNode getKakaoUserInfo(JsonNode accessToken) {
        Logger logger = LoggerFactory.getLogger(KakaoUserInfo.class);

        final String requestUrl = "https://kapi.kakao.com/v2/user/me";
        final CloseableHttpClient client = HttpClientBuilder.create().build();
        final HttpPost post = new HttpPost(requestUrl);

        // add header
        post.addHeader("Authorization", "Bearer " + accessToken);  // 토큰으로 authorization 권한 얻는 것.

        JsonNode returnNode = null;

        try {
            final HttpResponse response = client.execute(post);
            final int responseCode = response.getStatusLine().getStatusCode();
            final String msg = response.getStatusLine().getReasonPhrase();
            System.out.println("Sending 'POST' request to URL: " + requestUrl);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Response Message: " + msg);

            // JSON 형태 반환값 처리
            ObjectMapper mapper = new ObjectMapper();
            returnNode = mapper.readTree(response.getEntity().getContent());

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return returnNode;
    }
}
