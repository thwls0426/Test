//package com.example.login_test.user;
//
//import java.util.*;
//
//import lombok.RequiredArgsConstructor;
//import org.hibernate.validator.constraints.URL;
//import org.springframework.stereotype.Controller;
//import org.springframework.stereotype.Service;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import javax.servlet.http.HttpSession;
//import java.io.*;
//import java.net.HttpURLConnection;
//
//@Controller
//@RequiredArgsConstructor
//
//public class HttpCallService {
//
//    private final HttpSession httpSession;
//
//    @GetMapping("/")
//    public String index(Model model){
//        model.addAttribute("posts", postService.findAllDesc());
//
//        SessionUser user = (SessionUser) httpSession.getAttribute("user");
//
//        if(user != null){
//            model.addAttribute("userName", user.getName());
//        }
//        return "index";
//    }
//    }