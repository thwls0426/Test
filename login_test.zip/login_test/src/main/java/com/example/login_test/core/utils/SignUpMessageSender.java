package com.example.login_test.core.utils;

import net.nurigo.sdk.NurigoApp;
import net.nurigo.sdk.message.model.Message;
import net.nurigo.sdk.message.request.SingleMessageSendingRequest;
import net.nurigo.sdk.message.response.SingleMessageSentResponse;
import net.nurigo.sdk.message.service.DefaultMessageService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

@Configuration
public class SignUpMessageSender {

    // ** 인증 헤더에 사용될 토큰의 접두어 ("Bearer ")
    public static final String API_KEY = "NCSFJA2ENAK8VE9M";

    // ** 인증 헤더의 이름을 "Authorization"으로 설정.
    public static final String APISECRETKEY = "TZTXRMZOCWJHSRDMV3NEN4ZYCEB9UUMY";

    // ** 토큰의 서명을 생성하고 검증할 때 사용하는 비밀 키
    private static final String DOMAIN = "https://api.solapi.com";


    private static DefaultMessageService messageService = null;

    @Bean
    public void initialize() {
        // ** 반드시 계정 내 등록된 유효한 API 키, API Secret Key를 입력해주셔야 합니다!
        /* this.messageService = NurigoApp.INSTANCE.initialize(
                "INSERT_API_KEY",               apiKey
                "INSERT_API_SECRET_KEY",        apiSecretKey
                "https://api.coolsms.co.kr");   domain
         */
        messageService = NurigoApp.INSTANCE.initialize(API_KEY, APISECRETKEY, DOMAIN);
    }

    public static void sendMessage(String fromPhoneNumber, String toPhoneNumber, String text) {
        Message message = new Message();

        message.setFrom(fromPhoneNumber);
        message.setTo(toPhoneNumber);
        message.setText(text);

        SingleMessageSentResponse response = messageService.sendOne(new SingleMessageSendingRequest(message));
        System.out.println(response);
    }

//    @GetMapping(value = "/social/login/kakao", produces = MediaType.APPLICATION_JSON_VALUE)
//    @ApiOperation(value = "카카오 간편로그인 테스트", notes = "카카오 간편로그인 시 활용한다.")
//    @Description("Front로 부터 kakao Oauth를 받는다")
//    @CustomApiResponse
//    public void getKakaoUserInfo(String code) {
//        System.out.println("OAuth Code : "+code);
//        //////////////////////Token 정보 요청//////////////////////
//        try {
//            URL url = new URL("https://kauth.kakao.com/oauth/token");
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("POST");
//            conn.setDoOutput(true);
//
//            StringBuilder sb = new StringBuilder();
//            sb.append("grant_type=authorization_code");
//            sb.append("&client_id=" + "7e6fcafe9cbded6eacd03cfd7238f8ff");
//            sb.append("&code=" + code);
//            BufferedWriter bw = null;
//            try{
//                bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
//                bw.write(sb.toString());
//            }catch(IOException e){
//                thorw e;
//            }finally{
//                if(bw != null) bw.flush();
//            }
//            BufferedReader br = null;
//            String line = "", result = "";
//            try {
//                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//                while ((line = br.readLine()) != null) {
//                    result += line;
//                }
//            } catch (IOException e) {
//                throw e;
//            } finally {
//                if (br != null)
//                    br.close();
//            }
//            System.out.println("result : " + result);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        //////////////////////Token 정보 요청 끝//////////////////////
//    }
}
