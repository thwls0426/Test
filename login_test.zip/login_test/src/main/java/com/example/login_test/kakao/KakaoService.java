package com.example.login_test.kakao;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

@Transactional(readOnly = true) // 데이터 안정성을 위해 넣음
@RequiredArgsConstructor // 생성자
@Service
public class KakaoService {

    public String kakaoConnect() {
        StringBuffer url = new StringBuffer();
        url.append("http://kauth.kakao.com/oauth/authorize?");
        url.append("client_id=" + "f12393a3d014f5b41c1891bca7f2c800");
        url.append("&redirect_uri=http://localhost:8080/kakao/callback");
        url.append("&response_type=" + "code");
        return "redirect:" + url.toString();

    }


    public void kakaoLogin(String code) {
        try {
            System.out.println("kakao code : " + code);

            JsonNode access_token = getKakaoAccessToken(code);
            JsonNode userInfo = KakaoUserInfo.getKakaoUserInfo(access_token.get("access_token"));
            String member_id = userInfo.get("id").asText();

            String member_name = null;

            JsonNode properties = userInfo.path("properties");
            member_name = properties.path("nickname").asText(); //이름 정보 가져오는 것

            System.out.println("id : " + member_id);    //여기에서 값이 잘 나오는 것 확인 가능함.
            System.out.println("name : " + member_name);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public JsonNode getKakaoAccessToken(String code){
            final String RequestUrl = "https://kauth.kakao.com/oauth/token"; // Host
            final List<NameValuePair> postParams = new ArrayList<>();

            postParams.add(new BasicNameValuePair("grant_type", "authorization_code"));
            postParams.add(new BasicNameValuePair("client_id", "f12393a3d014f5b41c1891bca7f2c800")); // REST API KEY
            postParams.add(new BasicNameValuePair("redirect_uri", "http://localhost:8080/mytest04/kakao/callback")); // 리다이렉트 URI
            postParams.add(new BasicNameValuePair("code", code)); // 로그인 과정중 얻은 code 값

            final HttpClient client = HttpClientBuilder.create().build();
            final HttpPost post = new HttpPost(RequestUrl);

            JsonNode returnNode = null;

            try {
                post.setEntity(new UrlEncodedFormEntity(postParams));

                final HttpResponse response = client.execute(post);
                final int responseCode = response.getStatusLine().getStatusCode();

                System.out.println("\nSending 'POST' request to URL : " + RequestUrl);
                System.out.println("Post parameters : " + postParams);
                System.out.println("Response Code : " + responseCode);

                // JSON 형태 반환값 처리
                ObjectMapper mapper = new ObjectMapper();

                returnNode = mapper.readTree(response.getEntity().getContent());

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return returnNode;
        }
    }

