package com.example.login_test.kakao;


import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class KakaoController {
    private KakaoService kakao_service = new KakaoService();

    @GetMapping(value = "/kakao/oauth")// method = RequestMethod.GET)
    public String kakaoConnect(){

        return "redirect:" + kakao_service.kakaoConnect();

    }

    @GetMapping(value = "/kakao/callback", produces = "applicaiton/json")// method = {RequestMethod.GET,RequestMethod.POST})
    public String kakaoLogin(@RequestParam("code")String code, Error error){

        kakao_service.kakaoLogin(code);

        return "redirect:/index.do";
    }


    }



